"""Core27 -> SMPL22. Collapse extra spine joints in world space before localizing.

The upstream skin bind matrices supply the rest correction; never assume Core
indices or bone-local axes match SMPL. Output is Y-up, meters, xyzw.
"""

from __future__ import annotations
import numpy as np

SMPL_PARENTS = [
    -1,
    0,
    0,
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    9,
    9,
    12,
    13,
    14,
    16,
    17,
    18,
    19,
]
CORE_NAMES = [
    "Hips",
    "LeftUpLeg",
    "RightUpLeg",
    "Spine",
    "LeftLeg",
    "RightLeg",
    "Spine1",
    "LeftFoot",
    "RightFoot",
    "Spine3",
    "LeftToeBase",
    "RightToeBase",
    "Neck",
    "LeftShoulder",
    "RightShoulder",
    "Head",
    "LeftArm",
    "RightArm",
    "LeftForeArm",
    "RightForeArm",
    "LeftHand",
    "RightHand",
]


# Must match the SMPL axis contract used by cc-render's direction retargeter.
SMPL_PRIMARY_CHILD = [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, None, None, 15, 16, 17, None, 18, 19, 20, 21, None, None]
SMPL_AXES = np.array([[0,1,0], [0,-1,0], [0,-1,0], [0,1,0], [0,-1,0], [0,-1,0],
    [0,1,0], [0,0,1], [0,0,1], [0,1,0], [0,0,1], [0,0,1], [0,1,0],
    [1,0,0], [-1,0,0], [0,1,0], [1,0,0], [-1,0,0], [1,0,0], [-1,0,0], [1,0,0], [-1,0,0]], dtype=np.float64)


def align_directions(rotations, positions):
    """Carry Core bone directions into the canonical SMPL axis convention.

    Use posed endpoints, rather than a static rest correction, because collapsing
    Spine2 changes the Spine1->Spine3 direction as the intermediate joint bends.
    The shortest swing preserves the orientation's remaining twist.
    The pelvis retains its full rest-relative orientation: Hips->Spine is an
    anatomical offset, not the pelvis up axis (Core's offset leans back 34 deg).
    """
    result = rotations.copy()
    for i, child in enumerate(SMPL_PRIMARY_CHILD):
        if i == 0 or child is None:
            continue
        before = rotations[..., i, :, :] @ SMPL_AXES[i]
        after = positions[..., child, :] - positions[..., i, :]
        length = np.linalg.norm(after, axis=-1, keepdims=True)
        if (length < 1e-6).any():
            raise ValueError("coincident Core bone endpoints")
        after = after / length
        cross = np.cross(before, after)
        cosine = np.clip(np.sum(before * after, axis=-1), -1., 1.)
        skew = np.zeros(cross.shape[:-1] + (3, 3))
        skew[..., 0, 1], skew[..., 0, 2] = -cross[..., 2], cross[..., 1]
        skew[..., 1, 0], skew[..., 1, 2] = cross[..., 2], -cross[..., 0]
        skew[..., 2, 0], skew[..., 2, 1] = -cross[..., 1], cross[..., 0]
        swing = np.eye(3) + skew + (skew @ skew) / np.maximum(1. + cosine, 1e-8)[..., None, None]
        # Resolve a half-turn about a deterministic perpendicular axis.
        axis = np.cross(before, np.eye(3)[np.argmin(np.abs(before), axis=-1)])
        axis /= np.linalg.norm(axis, axis=-1, keepdims=True)
        half_turn = 2. * axis[..., :, None] * axis[..., None, :] - np.eye(3)
        swing = np.where((cosine < -1. + 1e-6)[..., None, None], half_turn, swing)
        result[..., i, :, :] = swing @ rotations[..., i, :, :]
    return result


def matrix_to_xyzw(m):
    """Stable quaternion extraction including rotations near pi."""
    m = np.asarray(m, dtype=np.float64)
    if m.shape[-2:] != (3, 3) or not np.isfinite(m).all():
        raise ValueError("invalid rotation matrices")
    result = []
    for r in m.reshape(-1, 3, 3):
        # Bar-Itzhack's symmetric eigenproblem, in xyzw order.
        k = (
            np.array(
                [
                    [
                        r[0, 0] - r[1, 1] - r[2, 2],
                        r[0, 1] + r[1, 0],
                        r[0, 2] + r[2, 0],
                        r[2, 1] - r[1, 2],
                    ],
                    [
                        r[0, 1] + r[1, 0],
                        r[1, 1] - r[0, 0] - r[2, 2],
                        r[1, 2] + r[2, 1],
                        r[0, 2] - r[2, 0],
                    ],
                    [
                        r[0, 2] + r[2, 0],
                        r[1, 2] + r[2, 1],
                        r[2, 2] - r[0, 0] - r[1, 1],
                        r[1, 0] - r[0, 1],
                    ],
                    [
                        r[2, 1] - r[1, 2],
                        r[0, 2] - r[2, 0],
                        r[1, 0] - r[0, 1],
                        np.trace(r),
                    ],
                ]
            )
            / 3
        )
        _, vectors = np.linalg.eigh(k)
        q = vectors[:, -1]
        result.append(q if q[3] >= 0 else -q)
    return np.array(result).reshape(m.shape[:-2] + (4,)).astype(np.float32)


class CoreAdapter:
    def __init__(self, names, parents, bind_transforms):
        self.names = list(names)
        if len(set(names)) != 27 or len(parents) != 27:
            raise ValueError("expected the released Core27 skeleton")
        self.indices = [self.names.index(n) for n in CORE_NAMES]
        for i, parent in enumerate(SMPL_PARENTS):
            if parent < 0:
                continue
            ancestor = parents[self.indices[i]]
            seen = set()
            while ancestor != self.indices[parent]:
                if ancestor < 0 or ancestor in seen:
                    raise ValueError(f"Core hierarchy mismatch at {CORE_NAMES[i]}")
                seen.add(ancestor)
                ancestor = parents[ancestor]
        bind = np.asarray(bind_transforms)
        if bind.shape != (27, 4, 4) or not np.isfinite(bind).all():
            raise ValueError("invalid Core skin bind transforms")
        height = np.ptp(bind[:, 1, 3])
        if not 1.0 < height < 2.5:
            raise ValueError("Core bind pose must be Y-up and meter-scaled")
        self.rest_inverse = np.linalg.inv(bind[self.indices, :3, :3])
        if not np.allclose(np.linalg.det(self.rest_inverse), 1.0, atol=1e-4):
            raise ValueError("Core bind contains scale or reflection")

    def convert(self, global_rotations, root_positions, joint_positions=None):
        rotations = np.asarray(global_rotations)
        roots = np.asarray(root_positions, dtype=np.float32)
        if rotations.shape[-3:] != (27, 3, 3) or roots.shape != rotations.shape[:-3] + (
            3,
        ):
            raise ValueError("incorrect Core motion dimensions")
        if not np.isfinite(rotations).all() or not np.isfinite(roots).all():
            raise ValueError("non-finite motion")
        world = rotations[..., self.indices, :, :] @ self.rest_inverse
        if joint_positions is not None:
            positions = np.asarray(joint_positions)
            if positions.shape != rotations.shape[:-2] + (3,) or not np.isfinite(positions).all():
                raise ValueError("incorrect Core joint positions")
            world = align_directions(world, positions[..., self.indices, :])
        local = world.copy()
        for i, p in enumerate(SMPL_PARENTS):
            if p >= 0:
                local[..., i, :, :] = (
                    np.swapaxes(world[..., p, :, :], -1, -2) @ world[..., i, :, :]
                )
        return matrix_to_xyzw(local), roots
