#!/usr/bin/env python3
"""Goal-only JSONL worker. Legacy authored motion requests fail closed.

Model generation lives in motion_backend; ownership/commit lives in
motion_service. There is intentionally no compatibility translation to timelines.
"""
import contextlib
import json
import os
import sys

from motion_policy import validate_request
from motion_service import MotionService


class ArdySession(MotionService):
    def __init__(self, model):
        from motion_backend import ArdyBackend
        super().__init__(ArdyBackend(model))


def ready_message(model):
    return dict(event="ready", model=f"core{model.gen_horizon_len}", fps=20, protocol=2,
                horizon_frames=model.gen_horizon_len, history_frames=model.num_frames_per_token)


def load_office_model():
    name = os.environ.get("ARDY_MODEL", "core40")
    if name not in ("core8", "core40"):
        raise ValueError("ARDY_MODEL must be core8 or core40")
    os.environ.setdefault("CUDA_VISIBLE_DEVICES", os.environ.get("ARDY_GPU", "0"))
    os.environ.setdefault("TEXT_ENCODER_DEVICE", "cpu")
    if os.environ["TEXT_ENCODER_DEVICE"] == "cpu":
        os.environ.setdefault("LLM2VEC_QUANTIZE", "none")
    from ardy.model.load_model import load_model, load_text_encoder
    # Upstream's default loader moves its encoder to the motion device after
    # construction. Inject it explicitly so CPU/local/API placement is retained.
    encoder = load_text_encoder(device=os.environ["TEXT_ENCODER_DEVICE"])
    return load_model(name, device=os.environ.get("ARDY_DEVICE", "cuda:0"),
                      text_encoder=encoder)


def relay():
    import socket
    with socket.socket(socket.AF_UNIX) as connection:
        connection.connect(os.environ["ARDY_SOCKET"])
        with connection.makefile("rwb") as stream:
            sys.stdout.buffer.write(stream.readline())
            sys.stdout.buffer.flush()
            for line in sys.stdin.buffer:
                try:
                    request = json.loads(line)
                    if isinstance(request, dict) and request.get('kind') == 'scene_step':
                        from scene_conditioning.rpc import validate_envelope
                        validate_envelope(request)  # Authentication remains in the resident daemon.
                    else:
                        validate_request(request)
                except ValueError as exc:
                    print(json.dumps({"error": str(exc), "frames": []}), flush=True)
                    continue
                stream.write(line)
                stream.flush()
                response = stream.readline()
                if not response:
                    break
                sys.stdout.buffer.write(response)
                sys.stdout.buffer.flush()


def main():
    if os.environ.get("ARDY_SOCKET"):
        relay()
        return
    with contextlib.redirect_stdout(sys.stderr):
        model = load_office_model()
        session = ArdySession(model)
    print(json.dumps(ready_message(model)), flush=True)
    for line in sys.stdin:
        try:
            request = json.loads(line)
            with contextlib.redirect_stdout(sys.stderr):
                response = session.step(request)
        except Exception as exc:
            response = {"error": str(exc), "frames": []}
        print(json.dumps(response, allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
