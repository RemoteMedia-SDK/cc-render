"""The only model-owned adapter allowed to call Ardy's sampler.

No reference poses, hand orientation edits or history alignment. The only
future conditioning is audited planned-navigation Root2D waypoints.
Core-to-SMPL conversion uses fixed bind calibration, never posed-joint repair.
"""
from pathlib import Path

import numpy as np

from ardy_adapter import CoreAdapter
from motion_policy import audit_conditioning, audit_planned_navigation
from motion_service import Candidate, digest


class ArdyBackend:
    @property
    def horizon_frames(self):
        return self.model.gen_horizon_len

    @property
    def history_frames(self):
        # Match upstream interactive loading: one native token, not 20 frames.
        return self.model.num_frames_per_token

    @property
    def model_id(self):
        return f"ardy/core{self.horizon_frames}"

    def __init__(self, model):
        import torch
        self.torch = torch
        self.model = model
        self.rep = model.motion_rep
        skeleton = self.rep.skeleton
        if self.rep.fps != 20 or self.history_frames != 4:
            raise ValueError("model-owned service requires 20FPS with four-frame native tokens")
        if skeleton.name != "cskel27" or model.gen_horizon_len not in (8, 40):
            raise ValueError("model-owned service requires Core27 Horizon8 or Horizon40")
        with np.load(Path(skeleton.folder) / "skin_standard.npz") as bind:
            if list(bind["rig_joint_names"]) != skeleton.bone_order_names:
                raise ValueError("Core bind joint order mismatch")
            self.calibration_id = digest(bind["bind_rig_transform"])
            self.adapter = CoreAdapter(skeleton.bone_order_names,
                                       skeleton.joint_parents.tolist(), bind["bind_rig_transform"])
        self.prompt = None
        self.features = None

    @property
    def joint_columns(self):
        """Native position columns of each end-effector chain (hands and feet)."""
        skeleton, start = self.rep.skeleton, self.rep.slice_dict["local_joints_positions"].start
        return {name: [start + 3 * (skeleton.bone_index[j] - 1) for j in skeleton.expand_joint_names([name])[1]]
                for name in ("LeftHand", "RightHand", "LeftFoot", "RightFoot")}

    @property
    def rotation_columns(self):
        """Native global-rotation (6D) columns of each end-effector joint."""
        skeleton, start = self.rep.skeleton, self.rep.slice_dict["global_rot_data"].start
        return {name: start + 6 * skeleton.bone_index[name]
                for name in ("LeftHand", "RightHand", "LeftFoot", "RightFoot", "LeftForeArm", "RightForeArm")}

    def _planned_navigation(self, navigation, history_len, window=None):
        """Native sampler arguments for planned navigation. The constraint set is built
        outside this module; the policy audit proves it is exactly the record's Root2D
        waypoints before anything is sampled."""
        rep, record = self.rep, navigation.record
        last = max(record["frames"])
        token = self.model.num_frames_per_token
        num_frames = history_len + max(self.horizon_frames, -(-(last + 1) // token) * token)
        window_joints = None
        if "keyframe" in record:
            # Decoded from the exact window the sampler continues from.
            with self.torch.inference_mode():
                window_joints = rep.inverse(rep.unnormalize(window), is_normalized=False)["posed_joints"][0].cpu().numpy()
        sets = navigation.constraints(rep.skeleton, history_len, self.model.device, window_joints)
        raw, mask = rep.create_conditions_from_constraints(sets, num_frames, False, self.model.device)
        root, heading = rep.slice_dict["root_pos"], rep.slice_dict["global_root_heading"]
        audit = audit_planned_navigation(mask, raw, record, history_len,
                                         (root.start, root.start + 1, root.start + 2, heading.start, heading.start + 1),
                                         self.joint_columns, window_joints, tuple(rep.skeleton.hip_joint_idx),
                                         rep.slice_dict["local_joints_positions"].start, self.rotation_columns)
        observed = rep.normalize(raw) * mask
        return num_frames, mask[None], observed[None], audit

    def generate(self, description, history, seed, navigation=None):
        """`navigation` optionally carries a planned_navigation record and its native
        constraint sets (audited Root2D waypoints, the only permitted future
        conditioning); otherwise there is none."""
        torch, model, rep = self.torch, self.model, self.rep
        window = None if history is None else history[:, -self.history_frames:]
        history_len = 0 if window is None else window.shape[1]
        if history_len % model.num_frames_per_token:
            # Preserve the latest generated samples; never repeat a pose to pad.
            history_len -= history_len % model.num_frames_per_token
            if not history_len:
                raise ValueError("insufficient model-generated token history")
            window = window[:, -history_len:]
        sampler_args = dict(num_frames=history_len + self.horizon_frames, num_denoising_steps=10,
                            motion_mask=None, observed_motion=None, cfg_weight=(2.0, 2.0),
                            init_history_sequence=window)
        if navigation is None:
            audit = audit_conditioning(sampler_args["motion_mask"], sampler_args["observed_motion"])
        else:
            num_frames, mask, observed, audit = self._planned_navigation(navigation, history_len, window)
            sampler_args.update(num_frames=num_frames, motion_mask=mask, observed_motion=observed)
        with torch.inference_mode(), torch.random.fork_rng():
            torch.manual_seed(seed)
            if self.prompt != description:
                self.features = model._encode_text([description])
                self.prompt = description
            samples = model.autoregressive_step(**sampler_args, text_feat=self.features[0],
                                                 text_pad_mask=self.features[1])
            # Waypoint look-ahead may extend sampling; the committed block stays one horizon.
            suffix = samples[:, history_len:history_len + self.horizon_frames].detach().clone()
            # Decode only for validation/playback; retain the raw suffix as history.
            output = rep.inverse(rep.unnormalize(suffix), is_normalized=False)
            joints = output["posed_joints"][0].cpu().numpy().copy()
            rotations = output["global_rot_mats"][0].cpu().numpy().copy()
            roots = output["root_positions"][0].cpu().numpy().copy()
            quaternions, converted_roots = self.adapter.convert(rotations, roots)
        return Candidate(suffix, joints, rotations, quaternions, converted_roots, audit)
