"""Closed goal protocol and fail-closed conditioning policy.

This module is an owner-review boundary. Its one runtime switch is the owner-approved
planned-grasp experiment (`planned_grasp_enabled`), off by default.
"""
from __future__ import annotations

import copy
import os
from motion_protocol import ENVELOPE_FIELDS, validate_identity

POLICY = "model-owned-v1"
FIELDS = ENVELOPE_FIELDS


def validate_request(request):
    if not isinstance(request, dict) or request.get("kind") != "motion_goal":
        raise ValueError("motion_goal v2 required; authored motion_request is retired")
    if set(request) != FIELDS or type(request.get("version")) is not int or request["version"] != 2:
        raise ValueError("motion_goal v2 requires exactly the closed goal protocol fields")
    validate_identity(request)
    goal = request["goal"]
    if not isinstance(goal, dict) or set(goal) != {"description"}:
        raise ValueError("unsupported_conditioning: only a semantic description is supported")
    text = goal["description"]
    if not isinstance(text, str) or not text.strip() or len(text) > 2048:
        raise ValueError("invalid semantic description")
    return copy.deepcopy(request)


def audit_conditioning(motion_mask, observed_motion):
    """Inspect actual sampler arguments, not a claimed kind or provenance label.

    Baseline rejects even an allocated zero mask: no future conditioning builder
    belongs in this path. Native history is supplied independently by the service.
    """
    if motion_mask is not None or observed_motion is not None:
        raise ValueError("forbidden future motion conditioning")
    return dict(policy=POLICY, future_nonzero=0, future_channels=[], exceptions=[])


def planned_grasp_enabled():
    """Owner-approved experiment (openspec add-planned-grasp-experiment, 2026-10-17): an
    arrived reach may carry hand targets planned from the grip before any block is
    measured. Off unless ARDY_PLANNED_GRASP=1; runs with it are exception-assisted."""
    return os.environ.get("ARDY_PLANNED_GRASP") == "1"


def grip_root_free():
    """Owner question 2026-10-17, "does it not work without [the pelvis]?": an experiment
    (off unless ARDY_GRIP_FREE_ROOT=1) where planned drawer-grip hand targets leave the root
    height free (ground position and heading stay planned) instead of carrying one."""
    return os.environ.get("ARDY_GRIP_FREE_ROOT") == "1"


def target_provenances():
    """Correction provenances that may carry pelvis heights and joint targets. `planned_grip`:
    owner direction 2026-10-17 (openspec add-declared-articulated-grips), a hand gripping a
    jointed part's handle, and moving it along its travel, is constrained in the first
    sample, without regeneration."""
    base = ("measured_miss", "planned_grip")
    return base + ("planned_grasp",) if planned_grasp_enabled() else base


PLANNED_NAVIGATION_CHANNELS = ["root_pos.x", "root_pos.z", "global_root_heading"]
KEYFRAME_FIELDS = {"frame", "source_frame", "root", "heading"}
KEYFRAME_MAX_LIFT_M = 0.45   # support keyframe: at most this far above or below its source
KEYFRAME_MAX_MOVE_M = 1.5    # ...and this far along the ground


def hip_heading(joints, hip_indices):
    """ARDY's heading from the hip line (0 faces +Z): atan2(dz, -dx) of right - left hip."""
    import math
    right, left = hip_indices
    d = [joints[right][k] - joints[left][k] for k in range(3)]
    return math.atan2(d[2], -d[0])


def keyframe_pose(source, source_heading, root, heading):
    """A generated pose moved rigidly on the ground plane: turned about its hips by
    (heading - source_heading) and translated so its hips are at `root`. Joint 0 is the hips."""
    import math
    import numpy as np
    source = np.asarray(source, float)
    d = heading - source_heading
    c, s = math.cos(d), math.sin(d)
    rotation = np.array([[c, 0., s], [0., 1., 0.], [-s, 0., c]])
    return (source - source[0]) @ rotation.T + np.asarray(root, float)


def audit_planned_navigation(motion_mask, raw_observed, record, history_len, columns, joint_columns=None,
                             window_joints=None, hip_indices=None, pose_start=None, rotation_columns=None):
    """Owner-approved exception (openspec add-generic-object-interactions:
    planned-root-navigation): Root2D waypoints from the service planner.

    Accept the actual sampler mask only if it constrains exactly the record's
    ground-plane channels (root x, root z, heading cos/sin) at exactly the
    record's frames, with the record's values. Root height is allowed only at
    frames listed in the record's measured-miss `pelvis_heights` (with a
    `correction` entry), at exactly those heights. Joints, rotations,
    velocities and foot contacts must stay unconstrained.
    `columns` is (x, y, z, heading_cos, heading_sin) in the native representation.

    Measured-miss `joint_targets` ([frame, joint, [x, y, z]]) may add hand or foot
    end effectors at pelvis-height frames only: `joint_columns` maps each joint to
    the native position columns of its end-effector chain (joint first, stored
    as x and z relative to the root and absolute y). A measured-miss wrist target
    (openspec add-conforming-hand-grasps) adds a fourth element, `rotation_xyzw`: that
    frame may then also hold the joint's six global-rotation columns (from
    `rotation_columns`), exactly the first two matrix columns of that rotation.
    Nothing else may change.

    A measured-miss support `keyframe` ({frame, source_frame, root, heading}) carries
    no pose: it names one frame of the sampler's own history window
    (`window_joints`, Core joint positions), which is moved rigidly so its hips are at
    `root` (the planned ground point at that frame, raised or lowered at most
    KEYFRAME_MAX_LIFT_M) facing the planned heading. That frame's mask may hold the
    root, heading and every joint position (from column `pose_start`), and only with
    exactly those values.
    """
    import math
    import numpy as np

    if not isinstance(record, dict) or record.get("provenance") != "planned_navigation":
        raise ValueError("future conditioning without a planned_navigation record")
    frames, positions, headings = record.get("frames"), record.get("positions"), record.get("headings")
    if (not isinstance(frames, list) or not frames or not isinstance(positions, list)
            or not isinstance(headings, list) or not len(frames) == len(positions) == len(headings)
            or any(type(f) is not int or f < 0 for f in frames) or len(set(frames)) != len(frames)):
        raise ValueError("malformed planned_navigation record")
    as_array = lambda value: np.asarray(value.detach().cpu().numpy() if hasattr(value, "detach") else value)
    mask, raw = as_array(motion_mask), as_array(raw_observed)
    if mask.ndim != 2 or raw.shape != mask.shape:
        raise ValueError("planned navigation mask must be one (frames, channels) sample")
    x, y, z, hc, hs = columns
    heights = record.get("pelvis_heights", [])
    if heights and not isinstance(record.get("correction"), dict):
        raise ValueError("pelvis heights require a measured-miss correction entry")
    heights = {int(f): float(v) for f, v in heights}
    if not set(heights) <= set(frames) or not all(math.isfinite(v) for v in heights.values()):
        raise ValueError("pelvis heights must sit on planned frames")
    rows = sorted(int(r) for r in np.flatnonzero(mask.any(1)))
    if rows != sorted(history_len + f for f in frames):
        raise ValueError("planned navigation mask frames disagree with the record")
    targets = record.get("joint_targets", [])
    if targets and (not isinstance(targets, list) or not joint_columns
                    or record.get("correction", {}).get("provenance") not in target_provenances()):
        raise ValueError("joint targets require a measured-miss correction and known joint columns")
    # A free-root planned grip: oriented hand targets on planned frames, no root height.
    free = (record.get("correction", {}).get("root_height") == "free"
            and record.get("correction", {}).get("provenance") == "planned_grip" and not heights)
    if free and any(not isinstance(t, list) or len(t) != 4 for t in targets):
        raise ValueError("a free-root grip target carries its wrist rotation")
    by_frame, rotated = {}, {}
    for target in targets:
        if (not isinstance(target, list) or len(target) not in (3, 4) or target[0] not in (frames if free else heights)
                or target[1] not in joint_columns or len(target[2]) != 3
                or not all(math.isfinite(v) for v in target[2]) or target[1] in by_frame.get(target[0], {})):
            raise ValueError("joint targets must name known joints at pelvis-height frames")
        if len(target) == 4:
            q = target[3]
            if (not rotation_columns or target[1] not in rotation_columns or not isinstance(q, list) or len(q) != 4
                    or not all(math.isfinite(v) for v in q) or abs(math.sqrt(sum(v * v for v in q)) - 1.) > 1e-3
                    or not isinstance(record.get("correction", {}).get("wrist"), dict)):
                raise ValueError("a wrist rotation target needs a recorded wrist correction and a unit quaternion")
            rotated.setdefault(target[0], {})[target[1]] = q
        by_frame.setdefault(target[0], {})[target[1]] = target[2]
    # Forearm co-rotations: only beside that side's recorded hand rotation, as recorded.
    for arm in record.get("forearm_targets", []):
        if (not isinstance(arm, list) or len(arm) != 3 or arm[1] not in ("LeftForeArm", "RightForeArm")
                or not rotation_columns or arm[1] not in rotation_columns
                or arm[1].replace("ForeArm", "Hand") not in rotated.get(arm[0], {})
                or not isinstance(arm[2], list) or len(arm[2]) != 4 or not all(math.isfinite(v) for v in arm[2])
                or abs(math.sqrt(sum(v * v for v in arm[2])) - 1.) > 1e-3 or arm[1] in rotated.get(arm[0], {})):
            raise ValueError("a forearm rotation needs its hand's recorded wrist rotation at that frame")
        rotated[arm[0]][arm[1]] = arm[2]
    keyframe = record.get("keyframe")
    pose_row, expected = None, None
    if keyframe is not None:
        if (not isinstance(keyframe, dict) or set(keyframe) != KEYFRAME_FIELDS
                or record.get("correction", {}).get("provenance") != "measured_miss"
                or window_joints is None or hip_indices is None or pose_start is None):
            raise ValueError("a keyframe requires a measured-miss correction and the sampler history")
        frame, source = keyframe["frame"], keyframe["source_frame"]
        if (type(frame) is not int or frame not in frames or frame in heights or frame in by_frame
                or type(source) is not int or not 0 <= source < len(window_joints)):
            raise ValueError("a keyframe must sit on a planned frame and name a history frame")
        source_pose = np.asarray(window_joints[source], float)
        root, heading = [float(v) for v in keyframe["root"]], float(keyframe["heading"])
        k = frames.index(frame)
        if (len(root) != 3 or not all(math.isfinite(v) for v in root + [heading])
                or not np.allclose([root[0], root[2], heading], [*positions[k], headings[k]], atol=1e-4)
                or abs(root[1] - source_pose[0][1]) > KEYFRAME_MAX_LIFT_M
                or math.dist((root[0], root[2]), (source_pose[0][0], source_pose[0][2])) > KEYFRAME_MAX_MOVE_M):
            raise ValueError("a keyframe must stand on the planned point facing the planned heading")
        pose_row = history_len + frame
        expected = keyframe_pose(source_pose, hip_heading(source_pose, hip_indices), root, heading)
    pose_columns = set() if pose_row is None else set(range(pose_start, pose_start + 3 * (len(expected) - 1)))
    allowed = {x, z, hc, hs} | ({y} if heights else set())
    for f in range(mask.shape[0]):
        used = set(int(c) for c in np.flatnonzero(mask[f]))
        joints = by_frame.get(f - history_len, {})
        extra = {c + k for j in joints for c in joint_columns[j] for k in range(3)}
        turns = rotated.get(f - history_len, {})
        extra |= {rotation_columns[j] + k for j in turns for k in range(6)}
        for j, (qx, qy, qz, qw) in turns.items():
            n = math.sqrt(qx * qx + qy * qy + qz * qz + qw * qw)
            qx, qy, qz, qw = qx / n, qy / n, qz / n, qw / n
            matrix = np.array([[1 - 2 * (qy * qy + qz * qz), 2 * (qx * qy - qz * qw), 2 * (qx * qz + qy * qw)],
                               [2 * (qx * qy + qz * qw), 1 - 2 * (qx * qx + qz * qz), 2 * (qy * qz - qx * qw)],
                               [2 * (qx * qz - qy * qw), 2 * (qy * qz + qx * qw), 1 - 2 * (qx * qx + qy * qy)]])
            c = rotation_columns[j]
            if not all(mask[f, c:c + 6]) or not np.allclose(raw[f, c:c + 6], np.concatenate([matrix[:, 0], matrix[:, 1]]),
                                                             atol=1e-4):
                raise ValueError("wrist rotation values disagree with the record")
        if f == pose_row:
            extra |= pose_columns | {y}
            local = np.concatenate([[e[0] - expected[0][0], e[1], e[2] - expected[0][2]] for e in expected[1:]])
            if (not mask[f, sorted(pose_columns | {x, y, z})].all()
                    or not np.allclose(raw[f, [x, y, z]], expected[0], atol=1e-4)
                    or not np.allclose(raw[f, pose_start:pose_start + len(local)], local, atol=1e-4)):
                raise ValueError("keyframe values are not the recorded move of the history frame")
        if not used <= allowed | extra:
            raise ValueError("planned navigation may constrain only root x/z and heading")
        for j, (px, py, pz) in joints.items():
            c = joint_columns[j][0]
            if not all(mask[f, c:c + 3]) or not np.allclose(raw[f, c:c + 3], [px - raw[f, x], py, pz - raw[f, z]], atol=1e-4):
                raise ValueError("joint target values disagree with the record")
    for f in frames:
        if keyframe is not None and f == keyframe["frame"]:
            continue
        has_height = bool(mask[history_len + f, y])
        if has_height != (f in heights) or (has_height and abs(raw[history_len + f, y] - heights[f]) > 1e-4):
            raise ValueError("root height is constrained only at recorded measured-miss frames")
    for f, (px, pz), h in zip(frames, positions, headings):
        row = history_len + f
        if not mask[row, [x, z, hc, hs]].all():
            raise ValueError("planned navigation record frame is not fully applied")
        if not all(math.isfinite(v) for v in (px, pz, h)) or not np.allclose(
                raw[row, [x, z, hc, hs]], [px, pz, math.cos(h), math.sin(h)], atol=1e-4):
            raise ValueError("planned navigation values disagree with the record")
    channels = (list(PLANNED_NAVIGATION_CHANNELS) + (["root_pos.y"] if heights or keyframe else [])
                + sorted({"joint." + t[1] for t in targets}) + (["keyframe.fullbody"] if keyframe else [])
                + sorted({"rotation." + t[1] for t in targets if len(t) == 4}
                         | {"rotation." + a[1] for a in record.get("forearm_targets", [])}))
    return dict(policy=POLICY, future_nonzero=int(np.count_nonzero(mask)),
                future_channels=channels, exceptions=[copy.deepcopy(record)])
