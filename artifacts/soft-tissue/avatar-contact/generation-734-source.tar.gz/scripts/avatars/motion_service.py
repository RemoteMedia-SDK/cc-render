"""Transactional model-owned generation. Validators can reject, never repair.

The backend is a service-owned adapter, not an extension point in the wire API.
Only newly sampled suffixes are committed; decoded/re-encoded history is not.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import time

import numpy as np

import motion_policy
import motion_safety
from session_frame import SessionFrame


@dataclass(frozen=True)
class Candidate:
    suffix: object
    joints: np.ndarray
    rotations: np.ndarray
    quaternions: np.ndarray
    roots: np.ndarray
    audit: dict


def array_bytes(value):
    if hasattr(value, "detach"):
        value = value.detach().cpu().numpy()
    value = np.ascontiguousarray(value)
    return str((value.shape, value.dtype)).encode() + value.tobytes()


def digest(value):
    return hashlib.sha256(array_bytes(value)).hexdigest()


def copy_history(value):
    if value is None:
        return None
    return value.clone() if hasattr(value, "clone") else value.copy()


def append_history(history, suffix, max_frames=40):
    if history is None:
        return copy_history(suffix)
    if isinstance(suffix, np.ndarray):
        return np.concatenate((history, suffix), axis=1)[:, -max_frames:]
    import torch
    return torch.cat((history, suffix), dim=1)[:, -max_frames:].detach()


class MotionService:
    # Generate a semantic block only while the queued motion ends within this of display.
    semantic_prefetch_ms = 600

    def __init__(self, backend):
        self.backend = backend
        self.horizon_frames = backend.horizon_frames
        if self.horizon_frames not in (8, 40):
            raise ValueError("unsupported native generation horizon")
        # Retain displayed context even after a full prefetched Core40 block.
        # Conditioning still uses only the backend's latest native token.
        self.history_capacity = max(40, self.horizon_frames + 12 + backend.history_frames)
        self.history = None
        self.timestamps = []
        self.source_history = []
        self.request = None
        self.artifact_id = None
        from motion_journal import MotionJournal
        self.journal = MotionJournal.from_environment()
        self.generation_count = 0
        # Fixed start placement: calibration applied to packaged roots only (session_frame.py).
        self.frame = SessionFrame.from_environment()

    def _prefix(self, request):
        if self.request is None:
            if request["pts_ms"] != 0:
                raise ValueError("new sessions must start at zero; caller poses are not history")
            return None, [], []
        for key in ("session_id", "seed"):
            if request[key] != self.request[key]:
                raise ValueError(f"session-owned {key} cannot change")
        revision = request["generation_revision"]
        if revision < self.request["generation_revision"]:
            raise ValueError("stale revision")
        if not self.request["pts_ms"] <= request["pts_ms"] <= self.timestamps[-1]:
            raise ValueError("displayed time must advance within generated history")
        if revision == self.request["generation_revision"]:
            if request["goal"] != self.request["goal"]:
                raise ValueError("goal changes require a new revision")
            return self.history, self.timestamps, self.source_history
        # Match renderer SceneDelivery's semantic handoff: an already generated
        # native token up to600ms ahead, never a relocated or retimed sample.
        end = self.timestamps[-1]
        latest = min(end, request['pts_ms'] + 600)
        anchor = end - ((end - latest + 199) // 200) * 200
        if anchor < request['pts_ms'] + 200:
            raise ValueError('insufficient queued native history for semantic handoff')
        keep = sum(t <= anchor for t in self.timestamps)
        if keep < self.backend.history_frames:
            raise ValueError("revision lacks a complete native history token")
        return self.history[:, :keep], self.timestamps[:keep], self.source_history[:keep]

    def step(self, request):
        request = motion_policy.validate_request(request)
        return self._step_validated(request,
            lambda history, seed: self.backend.generate(request['goal']['description'], history, seed),
            self._check_semantic_audit, prefetch_ms=self.semantic_prefetch_ms)

    @staticmethod
    def _check_semantic_audit(audit):
        if audit != motion_policy.audit_conditioning(None, None):
            raise ValueError("backend conditioning audit violates policy")

    def _step_validated(self, request, generate, check_audit, *, prefetch_ms=600, journal_context=None):
        """Shared transaction; callbacks are installed service code, never wire fields."""
        started = time.monotonic()
        history, timestamps, source_history = self._prefix(request)
        if timestamps and timestamps[-1] > request["pts_ms"] + prefetch_ms:
            return {"frames": []}
        seed = request["seed"] + self.generation_count
        attempt = self.journal.begin(request, seed, self.generation_count, history, timestamps, journal_context)
        try:
            candidate = generate(copy_history(history), seed)
            self.generation_count += 1
            attempt.candidate(candidate)
            return self._admit_candidate(request, candidate, history, timestamps, source_history,
                                         check_audit, started, seed, attempt)
        except Exception as error:
            try:
                attempt.finish('failed', error=f'{type(error).__name__}: {error}')
            except OSError as journal_error:
                raise RuntimeError(f'generation failed: {error}; failure journal could not be persisted: {journal_error}') from error
            raise

    def _admit_candidate(self, request, candidate, history, timestamps, source_history,
                         check_audit, started, seed, attempt):
        # Provenance is not accepted from the caller. This service trusts only its
        # installed backend, whose actual sampler arguments are policy checked.
        check_audit(candidate.audit)
        if candidate.suffix.shape[1] != self.horizon_frames:
            raise ValueError("backend must return one complete unmodified native suffix")
        base = timestamps[-1] if timestamps else 0
        stamps = [base + 50 * (i + 1) for i in range(self.horizon_frames)]
        previous = source_history[-1] if source_history else None
        for value in (candidate.joints, candidate.rotations, candidate.quaternions, candidate.roots):
            value.setflags(write=False)
        motion_safety.check_source_motion(candidate.joints, candidate.rotations, stamps,
                                          posture="dynamic", previous=previous)
        motion_safety.check_retargeted_packet(candidate.quaternions, candidate.roots, stamps)
        frames = self._frames(request, candidate, stamps)
        evidence = dict(
            policy=candidate.audit, model=self.backend.model_id,
            calibration=self.backend.calibration_id, request=request, seed=seed,
            parent_artifact=self.artifact_id, input_history=None if history is None else digest(history),
            history_end_pts_ms=timestamps[-1] if timestamps else None,
            generated_suffix=digest(candidate.suffix), source_joints=digest(candidate.joints),
            source_rotations=digest(candidate.rotations), quaternions=digest(candidate.quaternions),
            roots=digest(candidate.roots),
        )
        if not self.frame.identity:
            evidence['session_frame'] = self.frame.record()
        artifact_id = hashlib.sha256(json.dumps(evidence, sort_keys=True).encode()).hexdigest()
        attempt.finish('source_validated', artifact_id=artifact_id, provenance=evidence)
        # All validation, conversion, packaging and evidence precedes this transaction.
        self.history = append_history(history, candidate.suffix, self.history_capacity)
        self.timestamps = (timestamps + stamps)[-self.history_capacity:]
        self.source_history = (source_history + [
            (j.copy(), r.copy(), pts) for j, r, pts in zip(candidate.joints, candidate.rotations, stamps)
        ])[-self.history_capacity:]
        self.request = request
        self.artifact_id = artifact_id
        return dict(frames=frames, artifact_id=artifact_id, provenance=evidence,
                    audit=candidate.audit, metrics={"generation_ms": (time.monotonic() - started) * 1000})

    def _frames(self, request, candidate, stamps):
        # Source joints and rotations stay in ARDY's frame (evidence); the displayed root and
        # pelvis carry the session's fixed start placement.
        quaternions, roots = self.frame.packet(candidate.quaternions, candidate.roots)
        return [dict(kind="skeletal_pose", session_id=request["session_id"],
                     generation_revision=request["generation_revision"], skeleton_id="smpl22",
                     root_mode="world", joint_quats_xyzw=q.tolist(), root_pos=root.tolist(),
                     pts_ms=pts, fps=20, source_joints=j.tolist(), source_global_rot_mats=r.tolist())
                for q, root, j, r, pts in zip(quaternions, roots, candidate.joints, candidate.rotations, stamps)]
