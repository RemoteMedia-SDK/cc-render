//! Block incomplete LDL^T on the free-node edge pattern. A diagonal shift
//! stabilizes only the preconditioner; the physical system is unchanged.
use bevy::math::{DMat3, DVec3};

struct Entry {
    row: usize,
    col: usize,
    source: usize,
    common: Vec<[usize; 2]>,
}
pub(super) struct Pattern {
    rows: Vec<usize>,
    entries: Vec<Entry>,
}
impl Pattern {
    pub fn new(count: usize, edges: impl Iterator<Item = [usize; 2]>) -> Self {
        let signature: Vec<_> = edges.collect();
        let mut entries: Vec<_> = signature
            .iter()
            .enumerate()
            .map(|(source, [a, b])| {
                assert!(a < b);
                Entry {
                    row: *b,
                    col: *a,
                    source,
                    common: Vec::new(),
                }
            })
            .collect();
        entries.sort_by_key(|e| (e.row, e.col));
        let mut rows = vec![0; count + 1];
        for entry in &entries {
            rows[entry.row + 1] += 1;
        }
        for i in 1..rows.len() {
            rows[i] += rows[i - 1];
        }
        for p in 0..entries.len() {
            let (i, j) = (entries[p].row, entries[p].col);
            let (mut a, mut b) = (rows[i], rows[j]);
            let mut common = Vec::new();
            while a < p && b < rows[j + 1] {
                match entries[a].col.cmp(&entries[b].col) {
                    std::cmp::Ordering::Less => a += 1,
                    std::cmp::Ordering::Greater => b += 1,
                    std::cmp::Ordering::Equal => {
                        common.push([a, b]);
                        a += 1;
                        b += 1;
                    }
                }
            }
            entries[p].common = common;
        }
        Self { rows, entries }
    }
}
pub(super) struct Factor<'a> {
    pattern: &'a Pattern,
    lower: Vec<DMat3>,
    inverse: Vec<DMat3>,
}
impl<'a> Factor<'a> {
    pub fn new(
        pattern: &'a Pattern,
        diagonal: &[DMat3],
        block: impl Fn(usize) -> DMat3,
    ) -> Option<Self> {
        // 0.1 avoids repeated failed attempts for the nearly incompressible
        // cage. Doubling retries remain bounded; failure uses block Jacobi.
        for shift in [0.1, 0.2, 0.4, 0.8, 1.6, 3.2, 6.4, 12.8] {
            if let Some(factor) = Self::factor(pattern, diagonal, &block, shift) {
                return Some(factor);
            }
        }
        None
    }

    fn factor(
        pattern: &'a Pattern,
        diagonal: &[DMat3],
        block: &impl Fn(usize) -> DMat3,
        shift: f64,
    ) -> Option<Self> {
        let mut lower = vec![DMat3::ZERO; pattern.entries.len()];
        let mut weighted = lower.clone();
        let mut inverse = vec![DMat3::ZERO; diagonal.len()];
        for i in 0..diagonal.len() {
            if diagonal[i] == DMat3::ZERO {
                continue;
            }
            let mut d = diagonal[i] * (1.0 + shift);
            for p in pattern.rows[i]..pattern.rows[i + 1] {
                let entry = &pattern.entries[p];
                let mut s = block(entry.source).transpose();
                for [a, b] in &entry.common {
                    s -= weighted[*a] * lower[*b].transpose();
                }
                let l = s * inverse[entry.col];
                d -= l * s.transpose();
                weighted[p] = s;
                lower[p] = l;
            }
            d = (d + d.transpose()) * 0.5;
            let scale = diagonal[i]
                .x_axis
                .x
                .max(diagonal[i].y_axis.y)
                .max(diagonal[i].z_axis.z);
            if !ic_positive(d, scale * 1e-12) {
                return None;
            }
            inverse[i] = d.inverse();
            if !inverse[i].is_finite() {
                return None;
            }
        }
        Some(Self {
            pattern,
            lower,
            inverse,
        })
    }

    pub fn apply(&self, rhs: &[DVec3]) -> Vec<DVec3> {
        let mut result = rhs.to_vec();
        for i in 0..result.len() {
            let mut value = result[i];
            for p in self.pattern.rows[i]..self.pattern.rows[i + 1] {
                value -= self.lower[p] * result[self.pattern.entries[p].col];
            }
            result[i] = value;
        }
        for (v, d) in result.iter_mut().zip(&self.inverse) {
            *v = *d * *v;
        }
        for i in (0..result.len()).rev() {
            let value = result[i];
            for p in self.pattern.rows[i]..self.pattern.rows[i + 1] {
                result[self.pattern.entries[p].col] -= self.lower[p].transpose() * value;
            }
        }
        result
    }
}

fn ic_positive(d: DMat3, floor: f64) -> bool {
    if !d.is_finite() || d.x_axis.x <= floor {
        return false;
    }
    let first = d.x_axis.x.sqrt();
    let b = d.x_axis.y / first;
    let c = d.x_axis.z / first;
    let second = d.y_axis.y - b * b;
    if second <= floor {
        return false;
    }
    let e = (d.y_axis.z - b * c) / second.sqrt();
    d.z_axis.z - c * c - e * e > floor
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn block_factor_solves_dense_system_with_nonsymmetric_couplings_and_fixed_node() {
        // Three free blocks form a complete pattern. Node 1 is eliminated.
        // The block diagonally dominant SPD matrix has a known manufactured
        // solution; its dense product is independent of the factor traversal.
        let edges = [[0, 2], [0, 3], [2, 3]];
        let pattern = Pattern::new(4, edges.into_iter());
        let blocks = [
            DMat3::from_cols_array(&[0.2, 0.1, -0.3, 0.4, -0.1, 0.2, 0.1, 0.3, 0.2]),
            DMat3::from_cols_array(&[-0.1, 0.3, 0.2, 0.1, 0.2, 0.3, -0.2, 0.1, 0.1]),
            DMat3::from_cols_array(&[0.3, -0.2, 0.1, 0.2, 0.1, -0.1, 0.3, 0.1, 0.2]),
        ];
        let diagonal = [
            DMat3::IDENTITY * 3.0,
            DMat3::ZERO,
            DMat3::IDENTITY * 4.0,
            DMat3::IDENTITY * 5.0,
        ];
        let expected = [
            DVec3::new(0.2, -0.3, 0.7),
            DVec3::ZERO,
            DVec3::new(-0.5, 0.1, 0.4),
            DVec3::new(0.8, 0.3, -0.2),
        ];
        let rhs = [
            diagonal[0] * expected[0] + blocks[0] * expected[2] + blocks[1] * expected[3],
            DVec3::ZERO,
            blocks[0].transpose() * expected[0]
                + diagonal[2] * expected[2]
                + blocks[2] * expected[3],
            blocks[1].transpose() * expected[0]
                + blocks[2].transpose() * expected[2]
                + diagonal[3] * expected[3],
        ];
        let factor = Factor::factor(&pattern, &diagonal, &|i| blocks[i], 0.0).unwrap();
        for (actual, expected) in factor.apply(&rhs).iter().zip(expected) {
            assert!(actual.distance(expected) < 1e-12);
        }
    }

    #[test]
    fn incomplete_factor_is_symmetric_positive_and_rejects_bad_pivots() {
        let pattern = Pattern::new(4, [[0, 1], [0, 3], [1, 2], [2, 3]].into_iter());
        let diagonal = [DMat3::IDENTITY * 3.0; 4];
        let factor = Factor::new(&pattern, &diagonal, |_| DMat3::IDENTITY * -0.7).unwrap();
        let a = [DVec3::X, DVec3::Y, DVec3::Z, DVec3::ONE];
        let b = [DVec3::ONE, DVec3::X, -DVec3::Y, DVec3::Z];
        let dot = |x: &[DVec3], y: &[DVec3]| x.iter().zip(y).map(|(a, b)| a.dot(*b)).sum::<f64>();
        let ma = factor.apply(&a);
        let mb = factor.apply(&b);
        assert!(dot(&a, &ma) > 0.0);
        assert!((dot(&a, &mb) - dot(&b, &ma)).abs() < 1e-12);
        let invalid = DMat3::from_cols_array(&[1.0, 2.0, 0.0, 2.0, 1.0, 0.0, 0.0, 0.0, 1.0]);
        assert!(!ic_positive(invalid, 1e-12));
        let singleton = Pattern::new(1, [].into_iter());
        assert!(Factor::new(&singleton, &[invalid], |_| unreachable!()).is_none());
    }
}
