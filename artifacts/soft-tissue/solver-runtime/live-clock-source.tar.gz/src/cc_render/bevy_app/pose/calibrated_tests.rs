use super::*;

const IDENT_SOURCE: [[f32; 4]; 22] = [[0., 0., 0., 1.]; 22];

#[test]
fn actual_heeled_ankles_keep_bind_reference_and_full_source_rotation() {
    let fixture: serde_json::Value = serde_json::from_str(include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"), "/tests/fixtures/cc5-scene-fit-calibration.json"
    ))).unwrap();
    let quats = |key: &str| {
        serde_json::from_value::<[[f32; 4]; 22]>(fixture[key].clone()).unwrap().map(Quat::from_array)
    };
    let axes = serde_json::from_value::<[[f32; 3]; 22]>(fixture["axes"].clone()).unwrap().map(Vec3::from_array);
    let parent = Quat::from_array(serde_json::from_value(fixture["pelvis_parent"].clone()).unwrap());
    let own = quats("own");
    let inter = quats("inter");
    let reference = calibrated_cc5_world_frames(&quats("rest"), &axes, &inter, &own, parent);
    for i in [7, 8, 10, 11] {
        let p = SMPL_PARENTS[i] as usize;
        let local = (reference[p] * inter[i]).inverse() * reference[i];
        assert!(local.angle_between(own[i]) < 0.001, "foot {i} lost authored bind reference");
    }
    let mut input = IDENT_SOURCE;
    for (i, rotation) in [(0, Vec3::new(0.1, 0.4, -0.1)), (4, Vec3::new(0.3, 0.1, 0.2)),
                          (7, Vec3::new(0.2, -0.3, 0.4)), (8, Vec3::new(-0.3, 0.1, 0.2)),
                          (10, Vec3::new(0.1, 0.2, -0.1)), (11, Vec3::new(-0.2, 0.1, 0.3))] {
        input[i] = Quat::from_scaled_axis(rotation).to_array();
    }
    let output = fk_retarget_smpl_to_cc5_with_align(&input, &reference, &inter, parent, Quat::IDENTITY);
    let mut source = [Quat::IDENTITY; 22];
    let mut target = [Quat::IDENTITY; 22];
    for i in SMPL_TOPO {
        let p = SMPL_PARENTS[i];
        source[i] = if p < 0 { Quat::from_array(input[i]) } else { source[p as usize] * Quat::from_array(input[i]) };
        target[i] = if p < 0 { parent * output[i] } else { target[p as usize] * inter[i] * output[i] };
        assert!((target[i] * reference[i].inverse()).normalize().angle_between(source[i].normalize()) < 0.001,
                "bone {i} lost source rotation");
    }
}

#[test]
fn actual_cc5_scene_fit_geometry_matches_production_calibration() {
    let fixture: serde_json::Value = serde_json::from_str(include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"), "/tests/fixtures/cc5-scene-fit-calibration.json"
    ))).unwrap();
    let quats = |key: &str| {
        serde_json::from_value::<[[f32; 4]; 22]>(fixture[key].clone()).unwrap().map(Quat::from_array)
    };
    let axes = serde_json::from_value::<[[f32; 3]; 22]>(fixture["axes"].clone()).unwrap().map(Vec3::from_array);
    let parent = Quat::from_array(serde_json::from_value(fixture["pelvis_parent"].clone()).unwrap());
    let inter = quats("inter");
    let calibrated = calibrated_cc5_world_frames(&quats("rest"), &axes, &inter, &quats("own"), parent);
    for case in fixture["cases"].as_array().unwrap() {
        let input = serde_json::from_value::<[[f32; 4]; 22]>(case["quats"].clone()).unwrap();
        let expected = serde_json::from_value::<[[f32; 4]; 22]>(case["expected_local"].clone()).unwrap();
        let actual = fk_retarget_smpl_to_cc5_with_align(&input, &calibrated, &inter, parent, Quat::IDENTITY);
        for i in 0..22 {
            assert!(actual[i].normalize().dot(Quat::from_array(expected[i]).normalize()).abs() > 1.-1e-6,
                "production/geometry bone {i} mismatch");
        }
        let root = Vec3::from_array(serde_json::from_value(case["root"].clone()).unwrap());
        let realized = Vec3::from_array(serde_json::from_value(case["realized_root"].clone()).unwrap());
        assert!(root.abs_diff_eq(realized, 1e-6), "geometry must not adjust native root");
    }
}

#[test]
fn calibrated_transfer_preserves_mixed_arm_rotation_and_independent_wrist() {
    // Different bind frames, A-pose axes and unmapped intermediate joints.
    let rest = std::array::from_fn(|i| Quat::from_rotation_y(i as f32 * 0.07));
    let inter = [Quat::from_rotation_z(0.12); 22];
    let pelvis_parent = Quat::from_rotation_x(0.2);
    let own = std::array::from_fn(|i| {
        let p = SMPL_PARENTS[i];
        let parent = if p < 0 {
            pelvis_parent
        } else {
            rest[p as usize] * inter[i]
        };
        parent.inverse() * rest[i]
    });
    let axes = std::array::from_fn(|i| {
        Quat::from_euler(EulerRot::ZYX, 0.35, 0.03 * i as f32, -0.1)
            * Vec3::from_array(SMPL_BONE_AXES[i])
    });
    let reference = calibrated_cc5_world_frames(&rest, &axes, &inter, &own, pelvis_parent);
    let root = Quat::from_rotation_y(0.6);
    let collar = Quat::from_rotation_y(-0.4);
    let arm = Quat::from_euler(EulerRot::ZYX, 0.9, 0.4, 0.7);
    let elbow = Quat::from_rotation_y(-0.8);
    let wrist = Quat::from_rotation_x(1.2);
    let mut input = IDENT_SOURCE;
    for (i, q) in [(0, root), (13, collar), (16, arm), (18, elbow), (20, wrist)] {
        input[i] = q.to_array();
    }
    let output = fk_retarget_smpl_to_cc5_with_align(
        &input,
        &reference,
        &inter,
        pelvis_parent,
        Quat::IDENTITY,
    );
    let mut world = [Quat::IDENTITY; 22];
    for &i in SMPL_TOPO.iter() {
        let p = SMPL_PARENTS[i];
        world[i] = if p < 0 {
            pelvis_parent * output[i]
        } else {
            world[p as usize] * inter[i] * output[i]
        };
    }
    for (i, expected) in [
        (0, root),
        (13, root * collar),
        (16, root * collar * arm),
        (18, root * collar * arm * elbow),
        (20, root * collar * arm * elbow * wrist),
    ] {
        let transferred = world[i] * reference[i].inverse();
        assert!(
            transferred.angle_between(expected) < 0.001,
            "bone {i} lost orientation"
        );
    }
    // Bone axes still follow the same source directions despite bind tilt.
    let source_arm = root * collar * arm;
    let target_axis = world[16] * rest[16].inverse() * axes[16];
    assert!(target_axis.abs_diff_eq(source_arm * Vec3::X, 1e-5));
    assert!((world[0] * reference[0].inverse()).abs_diff_eq(root, 1e-5));
}

#[test]
fn calibrated_neutral_preserves_reference_except_authored_ankle_bind() {
    let rest = [Quat::from_rotation_y(0.2); 22];
    let own = [Quat::IDENTITY; 22];
    let inter = [Quat::IDENTITY; 22];
    let mut axes = SMPL_BONE_AXES.map(Vec3::from_array);
    axes[0] = Vec3::new(0., 0.97, 0.24).normalize();
    axes[16] = Vec3::new(0.8, -0.6, 0.);
    let parent = rest[0];
    let reference = calibrated_cc5_world_frames(&rest, &axes, &inter, &own, parent);
    assert!(reference[0].angle_between(rest[0]) < 0.001);
    let before = fk_retarget_smpl_to_cc5_axis_match_chained(
        &IDENT_SOURCE,
        &rest,
        &axes,
        &inter,
        &own,
        parent,
        Quat::IDENTITY,
        true,
    );
    let after = fk_retarget_smpl_to_cc5_with_align(
        &IDENT_SOURCE,
        &reference,
        &inter,
        parent,
        Quat::IDENTITY,
    );
    for i in 0..22 {
        let expected = if matches!(i, 7 | 8) { own[i] } else { before[i] };
        assert!(
            expected.angle_between(after[i]) < 0.001,
            "neutral bone {i} changed"
        );
    }
}
