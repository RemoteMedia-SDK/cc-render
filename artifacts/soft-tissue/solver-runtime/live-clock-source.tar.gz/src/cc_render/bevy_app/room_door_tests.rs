//! Actual room doorway geometry under diagnostic torques, not avatar motion.
use super::*;

#[test]
fn bedroom_door_obstructs_opens_releases_closes_and_publishes_current_geometry() {
    verify_room_door("scene-doors.json", "bedroom_door", "CC_ROOM_DOOR_TRACE", Vec3::new(0.78, 1.04, -0.5));
}

#[test]
fn bathroom_door_obstructs_opens_releases_closes_and_publishes_current_geometry() {
    verify_room_door("scene-bathroom-door.json", "bathroom_door", "CC_BATHROOM_DOOR_TRACE", Vec3::new(0.78, 1.04, -0.5));
}

#[test]
fn condo_entry_door_obstructs_opens_releases_closes_and_publishes_current_geometry() {
    verify_room_door("scene-entry-door.json", "condo_entry_door", "CC_ENTRY_DOOR_TRACE", Vec3::new(-0.65, 1.04, 0.45));
}

fn verify_room_door(manifest: &str, mechanism_id: &str, trace_key: &str, blocker_offset: Vec3) {
    let package = ScenePackage::load(&std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("scenes/toronto_condo").join(manifest)).unwrap();
    let index = package.mechanisms.iter().position(|m| m.id == mechanism_id).unwrap();
    let mechanism = &package.mechanisms[index];
    assert!(!package.static_solids().any(|s| s.id == mechanism.replaces_solid));
    assert!(package.cloths[0].collision_fixed_parts.contains(&mechanism.parts[0].id));
    let indices: Vec<_> = (0..package.mechanisms.len()).collect();
    let (mut app, mechanisms) = fixture_for_indices(package, &indices);
    let mechanism = mechanisms[index].clone();
    let doors = super::kitchen_drawers::bank_entities(&mut app, &mechanism);
    assert_eq!(doors.len(), 1);
    let door = doors[0];
    let mut trace = Vec::new();
    let mut blocker = None;
    for phase in 0..6 {
        if phase == 1 {
            blocker = Some(app.world_mut().spawn((RigidBody::Fixed, Collider::cuboid(0.08, 0.3, 0.06),
                Transform::from_translation(Vec3::from(mechanism.placement)+blocker_offset))).id());
        }
        if phase == 2 { app.world_mut().despawn(blocker.take().unwrap()); }
        let torque = match phase { 1 | 2 => 8., 4 => -8., _ => 0. };
        for tick in 0..180 {
            app.world_mut().entity_mut(door).insert(ExternalForce { torque:Vec3::Y*torque, ..default() });
            app.update();
            let state = super::cabinets::observed_door(&app, &mechanism, door);
            if tick == 179 { assert_room_phase(phase, &state); }
            let obstruction = blocker.map(|e| {
                let pose = app.world().get::<Transform>(e).unwrap();
                let shape = app.world().get::<Collider>(e).unwrap().raw.as_cuboid().unwrap();
                serde_json::json!({"position":pose.translation.to_array(),
                    "half_extents":[shape.half_extents.x,shape.half_extents.y,shape.half_extents.z]})
            });
            trace.push(serde_json::json!({"frame":phase*180+tick,"phase":phase,
                "parts":[state],"obstruction":obstruction}));
        }
        assert_current_snapshots(&app, &mechanism, &doors);
    }
    if let Ok(path) = std::env::var(trace_key) {
        use std::io::Write;
        let mut file = std::fs::OpenOptions::new().write(true).create_new(true).open(path).unwrap();
        file.write_all(&serde_json::to_vec(&serde_json::json!({
            "scope":"Diagnostic torques on room door; no avatar or runtime actuator",
            "mechanism":mechanism.id,"placement":mechanism.placement,"frames":trace})).unwrap()).unwrap();
    }
}

fn assert_room_phase(phase: usize, state: &serde_json::Value) {
    let angle = state["angle_degrees"].as_f64().unwrap();
    match phase {
        0 | 4 | 5 => assert!(angle.abs() < 1., "not closed: {state}"),
        1 => assert!((10. ..70.).contains(&angle), "obstruction missed: {state}"),
        _ => assert!((angle-90.).abs() < 1., "not open: {state}"),
    }
    if phase == 3 || phase == 5 {
        assert!(state["angular_speed_rad_s"].as_f64().unwrap() < 0.01, "not settled: {state}");
    }
}
