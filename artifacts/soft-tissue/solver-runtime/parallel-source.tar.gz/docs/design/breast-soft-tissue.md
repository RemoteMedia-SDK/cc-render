# Base-avatar volumetric tissue

Status: isolated, opt-in Bevy prototype on `feat/breast-soft-tissue`, based on
`ea65ebb68`. The replacement is **not enabled by default or production-ready**.
The current implementation and evidence are described here; the
[development history](breast-soft-tissue-history.md) preserves earlier designs,
failed experiments and superseded checkpoints.

## Scope and ownership

Replace the base avatar's breast-bone springs with a small volumetric tissue
simulation. ARDY remains the only body/root motion author. The renderer samples
unchanged committed motion and deforms the mesh; it does not add joint targets,
IK, root corrections or pose clamps. See [motion ownership](model-owned-motion.md).

The user's base-avatar request resolves to:

- `../remotemedia-sdk-office-main/avatars/processed/beautiful_assistant.smpl_aligned.glb`
- `../remotemedia-sdk-office-main/avatars/beautiful_assistant.arkit_map.resolved.json`
- GLB SHA-256: `23060843839654603f26d7aae6a955cf09c86bb2b39de8bf70bfc5e70d1062a9`

No separate `beautiful_avatar` asset was found. The current lab uses this base
mesh, with no clothing or condo geometry. Other agents' worktrees and renderers
are not changed by this work.

## Current simulation

Each side has 256 world-space nodes; the left/right cages contain 828/819
tetrahedra. Distributed fixed attachments follow the sampled chest frame; the
remaining 192 nodes per side respond to inertia, gravity, elastic forces and
viscosity. Fitted unloaded reference coordinates preserve the authored loaded
shape under gravity. All solver quantities use f64 and SI units.

The current asset is
`assets/tissue/beautiful_assistant.base-viscous-prototype.json`. Its parameters
are engineering choices, **not measured anatomical calibration**:

| Parameter | Value |
| --- | ---: |
| Density | 950 kg/m³ |
| Shear modulus | 1,500 Pa |
| Bulk modulus | 500,000 Pa |
| Quartic corotated-strain coefficient | 8 |
| Shear / bulk viscosity | 15 / 5,000 Pa s |
| Integration | Variable-step BDF2; backward-Euler startup |
| Maximum nonlinear iterations | 8 |

Elasticity uses corotated strain with finite volume resistance. Viscous forces
come from an objective Green-strain potential, so a rigid translation or
rotation does not create viscous strain. Legacy edge damping is disabled in this
asset. The implicit solve uses an approximate PSD tangent, sparse 3×3 block
assembly, preconditioned conjugate gradients, and energy/positive-volume line search.

The global force and Newton-correction stopping limits are 0.1 mN and 0.1 µm.
The linear solve uses block incomplete LDLᵀ preconditioning on the free-node
edge pattern, cached once per cage and shared immutably across cloned states.
A diagonal shift stabilizes only that preconditioner; the physical matrix,
forces and objective are unchanged. Positive-pivot checks and bounded shift
retries precede a block-Jacobi fallback. This is an incomplete factorization,
not an exact factorization of the physical system; see the general
[shifted incomplete-factorization approach](https://libeigen.gitlab.io/eigen/docs-nightly/classEigen_1_1IncompleteCholesky.html).

PCG checks the true residual against the original matrix before returning,
restarting if the recursive residual has drifted. It requires relative residual
≤1e-9 within 256 iterations or returns `LinearSolveFailed`; failed state is not
committed. The tighter tolerance preserves the existing repeated free-fall
velocity test. The earlier 1e-7 candidate failed that test and was not retained.
All 18,132 linear solves in the recorded CPU workload meet the new tolerance
(maximum 9.99996e-10). This is a linear-solve guarantee, not proof that every
nonlinear solve reaches its separate force/correction limits before its cap.

The Bevy adapter advances at fixed source-time steps, with a cloned solve for
fractional display time. Failed inversion/contact steps retry recursively at
smaller intervals without committing failed history. The runtime rate default
remains 120 Hz; the latest main review uses 240 Hz explicitly.

Independent regions solve concurrently on Bevy's existing compute task pool.
Every task operates on trial state and joins before collision checks or commit.
Results are inspected in region order, so simultaneous failures retain the
same first error as sequential execution. A missing pool or single region uses
the sequential path; no worker is created per substep. Contact refreshes remain
sequential. Cross-region contact is not currently modeled, so this concurrency
does not remove any existing mechanical coupling.

## Rendering and contact

The adapter reads the same calibrated rig transforms used for display and
checks sampled skin against displayed skin. Tissue displacement is embedded in
the original surface before ordinary GPU skinning; normals and tangents are
updated for normal PBR, depth and shadow rendering. Requested volumetric tissue
excludes the legacy breast springs, preventing both systems from deforming the
same tissue. The lab disables all legacy secondary chains for its comparison.

Body contact uses 45,940 torso/arm triangles and 1,502 embedded skin samples.
Conservative vertex-face sweeps cover linear endpoint trajectories. Normal
penalties are weighted by represented surface area, with 0.5 mm clearance and
0.1 mm residual allowance. Refreshed contacts re-solve from the original physical
state; they never project the rendered mesh or change body motion.

Swept bounds are computed once per skin vertex and shared between adjacent
triangles. Each contact query builds a local tree containing only triangles whose
bounds overlap the tissue samples' swept region (693 faces on average in the
recorded jump). Dense local tree IDs map back to sorted original face IDs.
The region and tree are rebuilt after every contact re-solve, including retries
and fractional display steps. No tree or physical state is retained between
queries. Exhaustive-query tests cover motion, rewinds and empty regions.

Known contact limits: no edge-edge, mutual breast, friction or environmental
contact; no bound on curved FK trajectories between sampled endpoints. The
current jump activates zero contacts. A moving-triangle compression/release
fixture passes, but broader active contact on the actual avatar is unfinished.

Position-affecting facial morphs are included in sampled contact geometry when
the body clock advances. Changing those morphs at a paused body timestamp still
fails explicitly. Owner clarification about independent tissue settling remains
pending: the existing contract says to “pause the simulation/motion clock” on
underrun, while facial animation is separate. Do not silently change this policy.

## Review evidence

Open the [current review page](../../artifacts/soft-tissue/temporal-integration/index.html)
for front/side video, normal/quarter-speed playback, rate comparisons and plots.
The unchanged eight-second ARDY recording contains repeated jumps; every source
sample is retained. Each capture has 478 matching display frames, all 160 source
packets, and the final 8,000 ms timestamp. Source and encoded video timestamps
are verified. Front and side traces match exactly.

| Check | Maximum measured difference |
| --- | ---: |
| 120 / 240 Hz surface displacement envelope | 2.072 mm |
| 240 / 480 Hz surface displacement envelope | 0.786 mm |
| 240 / 480 Hz tissue centroid | 0.432 mm |
| 8 / 32 nonlinear iterations at 240 Hz, centroid | 0.048 mm |

Whole-sequence peak skin displacement at 240/480 Hz is 37.85/38.17 mm; minimum
element volume ratios are 0.8553/0.8588. These sensitivity checks do not establish
anatomical accuracy or bound every vertex's timestep error. Independent rigid
oscillator and nonlinear viscous-tetrahedron tests also verify temporal response.

The current source passes **58 focused tissue tests**. The Python suite has eight
passing tests and one existing root-acceptance source-slice failure. Its scan
extends beyond `resolve_root` into unrelated code; the test has not been weakened.
Ripwire's quality gate remains non-clean at eight major findings.

## Runtime measurements

Connectivity indices are now precomputed once per tetrahedron. Elastic,
viscous and contact assembly reuse these indices without changing summation
order, material laws or solver settings. In an isolated CPU replay of recorded
attachment frames, assembly time fell from 12.18 to 6.10 s and total solve time
from 26.43 to 20.36 s. All 512 nodes at all 1,908 steps are byte-identical to the
baseline. This benchmark omits body contact, rendering and fractional display
solves; it is a profiling workload, not source-motion acceptance evidence.

The full GPU lab replay with this change also matches all 478 recorded tissue
responses exactly. It took **44.56 wall seconds for eight source seconds**.
Shared-host load affects stage timings, and PNG/capture overhead is included.
This is not a real-time performance result. Source archives, input hashes,
counters, full node trajectories and comparisons are under
`artifacts/soft-tissue/solver-runtime/`.

The subsequent collision optimization reduced measured broad-phase work from
8.01 to 1.07 s over the same jump. Candidate faces, all 478 traced tissue
responses, and source timestamps remain exactly equal. The latest GPU replay
took 36.97 wall seconds; it rendered/read back every frame but skipped PNG
writes. Compare against the matching trace-only baseline (42.73 s), not the
PNG capture above. This still does not establish interactive performance.
Evidence and source snapshots are under `artifacts/soft-tissue/collision-search/`.
Set `CC_TISSUE_LAB_TRACE_ONLY=1` for this diagnostic mode; its captures cannot
be encoded as video because they intentionally contain no saved images.

An isolated inexact-solve experiment reduced CPU cost further but differed from
the capped-CG reference by as much as 1.579 mm at a node. It is **not adopted**.
Its forcing-term idea is informed by
[Eisenstat and Walker](https://users.wpi.edu/~walker/Papers/forcing_terms,SISC_17,1996,16-32.pdf);
their convergence theory does not certify this approximate-Hessian solver.

The residual-checked preconditioned solver takes 22.13 s on the CPU replay,
versus 20.36 s for the earlier unconverged 128-iteration solve. Its stronger
accuracy therefore costs time relative to that old cap. A separately converged
block-Jacobi reference at 1e-7 takes 27.46 s; all recorded node positions differ
from that reference by at most 0.000000653 mm. The current tolerance is 100×
tighter, so these timings are not a same-tolerance algorithm benchmark.
See `solver-runtime/ic0-integrated-comparison.json` for full-node differences
and residual measurements. Real-time performance remains unfinished.

The integrated GPU captures complete all 478 frames through 8,000 ms, with
unchanged source timestamps and attachment frames. Front/side traces match
exactly; full captures take 38.63 / 39.27 s including PNG saving. Compared with
the earlier capped solver, the maximum envelope/centroid differences are
0.00000373 / 0.00000216 mm. These summaries do not bound every vertex.
The review page now defaults to `preconditioned-front-side.mp4`; older rate
comparisons are retained and labeled. Both individual videos and the paired
video have verified encoded timestamps. Raw front 850 ms and side 7,216 ms
frames were inspected for framing and surface continuity; broader visual
and active-contact acceptance remains pending.

Concurrent-region execution preserves all traced physical values and source
timestamps in a matching trace-only GPU replay. Elasticity time falls from
27.33 to 14.52 s (46.9%); total capture time falls from 38.46 to 25.66 s.
Sampling/collision stages remain approximately 2.4 / 1.6 s. These are measured
shared-host improvements, not real-time certification. The new tests also
compare every node position and velocity against sequential execution and check
deterministic failure selection and whole-interval rollback. Evidence is in
`solver-runtime/parallel-gpu-comparison.json`; the viewable videos remain the
preceding sequential capture, whose recorded physical response is identical.

## Reproduction

From this worktree, build and validate:

```sh
cargo test --offline --lib tissue -- --nocapture
python -m unittest discover -s tests -v
cargo build --offline --example tissue_lab
```

Run a fresh GPU lab capture with an output directory that does not already exist:

```sh
CC_AVATAR_TISSUE_HZ=240 RUST_LOG=info target/debug/examples/tissue_lab \
  ../remotemedia-sdk-office-main/avatars/processed/beautiful_assistant.smpl_aligned.glb \
  ../remotemedia-sdk-office-main/avatars/beautiful_assistant.arkit_map.resolved.json \
  artifacts/soft-tissue/lab-jump-01/packets.ndjson \
  assets/tissue/beautiful_assistant.base-viscous-prototype.json \
  front artifacts/soft-tissue/new-capture
```

Use `side` for the other fixed camera. `CC_AVATAR_TISSUE_ITERATIONS` controls the
iteration budget. The numerical profiling script accepts a new output label and
optimization level, for example:

```sh
python artifacts/soft-tissue/solver-runtime/profile.py fresh-profile 1 residual
```

Before default replacement: establish interactive runtime performance, validate
broader actual-avatar contact and facial/pause behavior, retain source-motion
fidelity, and complete the final code/visual audit. The existing jump harness
provides a reproducible input; its successful completion alone is insufficient.
