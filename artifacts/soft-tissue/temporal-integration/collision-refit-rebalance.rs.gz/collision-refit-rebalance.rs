//! Read-only, source-time skin contact. Body motion stays kinematic; only the
//! embedded tissue degrees of freedom receive the normal reaction.
//! Sweeps certify linear vertex trajectories, not the unsampled curved motion.
use super::tissue_surface::TissueSurface;
use crate::cc_render::soft_tissue::{
    ContactMetrics, EmbeddedPoint, Frame, PlaneContact, Tissue, TissueAsset, VertexBinding,
};
use bevy::math::DVec3;
use parry_ccd::{
    bounding_volume::Aabb,
    math::Point,
    partitioning::{Qbvh, QbvhUpdateWorkspace},
    query::PointQueryWithLocation,
    shape::Triangle,
};

const CLEARANCE: f64 = 0.0005;
const RESIDUAL: f64 = 0.0001;
// Numerical penalty, including each sample's represented rest area. This is
// not an anatomical material measurement or a support-garment parameter.
const PRESSURE_STIFFNESS: f64 = 1e10;

#[derive(Debug, thiserror::Error)]
#[error("tissue skin contact did not resolve within the sampled step")]
pub(super) struct ContactUnresolved;

pub(super) struct ContactPose {
    pub frames: Vec<Frame>,
    pub skin: Vec<DVec3>,
}

struct SkinSample {
    vertex: usize,
    binding: VertexBinding,
    area: f64,
}

pub(super) struct BodyContacts {
    triangles: Vec<[usize; 3]>,
    samples: Vec<SkinSample>,
    broad_phase: parking_lot::Mutex<SweptTree>,
}

/// Acceleration data only: every leaf is updated for every attempted interval,
/// including fractional display steps, rejected steps and session rewinds.
/// A cached tree never carries contact forces or physical integration history.
#[derive(Default)]
struct SweptTree {
    tree: Qbvh<usize>,
    workspace: QbvhUpdateWorkspace,
}

impl SweptTree {
    fn update(&mut self, triangles: &[[usize; 3]], old: &[DVec3], end: &[DVec3]) -> &Qbvh<usize> {
        let bounds = |i: &usize| {
            swept_bounds(
                triangles[*i].iter().flat_map(|v| [old[*v], end[*v]]),
                CLEARANCE,
            )
        };
        if self.tree.raw_nodes().is_empty() {
            self.tree
                .clear_and_rebuild((0..triangles.len()).map(|i| (i, bounds(&i))), 0.0);
        } else {
            for i in 0..triangles.len() {
                self.tree.pre_update_or_insert(i);
            }
            self.tree.refit(0.0, &mut self.workspace, bounds);
            self.tree.rebalance(0.0, &mut self.workspace);
        }
        &self.tree
    }
}

impl BodyContacts {
    pub fn new(surfaces: &[TissueSurface]) -> anyhow::Result<Self> {
        let mut triangles = Vec::new();
        let mut samples = Vec::new();
        let mut offset = 0;
        for surface in surfaces {
            triangles.extend(
                surface
                    .collision_triangles
                    .iter()
                    .map(|t| t.map(|i| i + offset)),
            );
            let areas = surface.sample_areas();
            let mut unique = std::collections::BTreeSet::new();
            for binding in &surface.binding().vertices {
                anyhow::ensure!(
                    unique.insert(binding.vertex)
                        && binding.influence > 0.0
                        && areas[binding.vertex] > 0.0,
                    "body contact requires a single positive embedding per skin sample"
                );
                samples.push(SkinSample {
                    vertex: binding.vertex + offset,
                    binding: binding.clone(),
                    area: areas[binding.vertex],
                });
            }
            offset += surface.binding().vertex_count;
        }
        Ok(Self {
            triangles,
            samples,
            broad_phase: Default::default(),
        })
    }

    pub fn counts(&self) -> (usize, usize) {
        (self.triangles.len(), self.samples.len())
    }

    /// Re-solve from the original physical state for each refreshed contact set.
    /// Never integrate a step twice or project the rendered positions afterward.
    pub fn resolve(
        &self,
        original: &[Tissue],
        candidate: &mut Vec<Tissue>,
        asset: &TissueAsset,
        old: &ContactPose,
        end: &ContactPose,
        dt: f64,
    ) -> anyhow::Result<Vec<ContactMetrics>> {
        let mut broad_phase = self.broad_phase.lock();
        let tree = broad_phase.update(&self.triangles, &old.skin, &end.skin);
        for _ in 0..4 {
            let contacts = self.planes(tree, original, candidate, asset, old, end, CLEARANCE)?;
            if contacts.iter().all(Vec::is_empty) {
                return Ok(vec![ContactMetrics::default(); original.len()]);
            }
            let mut solved = original.to_vec();
            let mut metrics = Vec::new();
            for (i, solver) in solved.iter_mut().enumerate() {
                metrics.push(solver.step_with_contacts(
                    dt,
                    end.frames[i],
                    DVec3::NEG_Y * 9.81,
                    &contacts[i],
                )?);
            }
            let inner = self.planes(
                tree,
                original,
                &solved,
                asset,
                old,
                end,
                CLEARANCE - RESIDUAL,
            )?;
            let valid = inner.iter().all(Vec::is_empty)
                && metrics.iter().all(|m| m.maximum_penetration_m <= RESIDUAL);
            *candidate = solved;
            if valid {
                return Ok(metrics);
            }
        }
        Err(ContactUnresolved.into())
    }

    fn planes(
        &self,
        tree: &Qbvh<usize>,
        old_solvers: &[Tissue],
        end_solvers: &[Tissue],
        asset: &TissueAsset,
        old: &ContactPose,
        end: &ContactPose,
        clearance: f64,
    ) -> anyhow::Result<Vec<Vec<PlaneContact>>> {
        let mut result = vec![Vec::new(); end_solvers.len()];
        let mut hits = Vec::new();
        for sample in &self.samples {
            let (old_point, old_embedded) = embedded(sample, asset, old);
            let (end_point, end_embedded) = embedded(sample, asset, end);
            let ids = asset.regions[sample.binding.region].tetrahedra[sample.binding.tetrahedron];
            let world = |point: DVec3, embedded: EmbeddedPoint, solver: &Tissue| {
                point
                    + ids
                        .iter()
                        .zip(embedded.barycentric)
                        .map(|(i, w)| solver.positions()[*i] * (w * embedded.influence))
                        .sum::<DVec3>()
            };
            let a = world(old_point, old_embedded, &old_solvers[sample.binding.region]);
            let b = world(end_point, end_embedded, &end_solvers[sample.binding.region]);
            hits.clear();
            tree.intersect_aabb(&swept_bounds([a, b], clearance), &mut hits);
            hits.sort_unstable();
            let mut local = Vec::new();
            for face in &hits {
                let t = self.triangles[*face];
                let from = [a, old.skin[t[0]], old.skin[t[1]], old.skin[t[2]]];
                let to = [b, end.skin[t[0]], end.skin[t[1]], end.skin[t[2]]];
                if let Some(witness) = sweep(from, to, clearance)? {
                    let surface_point = (0..3)
                        .map(|i| to[i + 1] * witness.barycentric[i])
                        .sum::<DVec3>()
                        + witness.normal * clearance;
                    local.push(PlaneContact {
                        point: end_embedded,
                        surface_point,
                        normal: witness.normal,
                        stiffness_n_per_m: PRESSURE_STIFFNESS * sample.area,
                    });
                }
            }
            // Neighboring faces represent one surface sample, not duplicated area.
            let count = local.len() as f64;
            for plane in &mut local {
                plane.stiffness_n_per_m /= count;
            }
            result[sample.binding.region].extend(local);
        }
        Ok(result)
    }
}

fn embedded(
    sample: &SkinSample,
    asset: &TissueAsset,
    pose: &ContactPose,
) -> (DVec3, EmbeddedPoint) {
    let binding = &sample.binding;
    let region = &asset.regions[binding.region];
    let rest: DVec3 = region.tetrahedra[binding.tetrahedron]
        .iter()
        .zip(binding.barycentric)
        .map(|(i, w)| {
            pose.frames[binding.region].point(region.initial_positions[*i].into())
                * (w * binding.influence)
        })
        .sum();
    let offset = pose.skin[sample.vertex] - rest;
    (
        offset,
        EmbeddedPoint {
            tetrahedron: binding.tetrahedron,
            barycentric: binding.barycentric,
            influence: binding.influence,
            offset,
        },
    )
}

fn swept_bounds(points: impl IntoIterator<Item = DVec3>, radius: f64) -> Aabb {
    let (lo, hi) = points.into_iter().fold(
        (DVec3::splat(f64::INFINITY), DVec3::splat(f64::NEG_INFINITY)),
        |(lo, hi), p| (lo.min(p), hi.max(p)),
    );
    Aabb::new(
        Point::from((lo - DVec3::splat(radius)).to_array()),
        Point::from((hi + DVec3::splat(radius)).to_array()),
    )
}

#[derive(Debug)]
struct Witness {
    barycentric: [f64; 3],
    normal: DVec3,
    distance: f64,
}

fn witness(x: [DVec3; 4]) -> anyhow::Result<Witness> {
    // Query relative to the point for translation-invariant f64 precision.
    let [a, b, c] = [x[1], x[2], x[3]].map(|v| Point::from((v - x[0]).to_array()));
    let (_, location) =
        Triangle::new(a, b, c).project_local_point_and_get_location(&Point::origin(), false);
    let barycentric = location
        .barycentric_coordinates()
        .ok_or(ContactUnresolved)?;
    let delta: DVec3 = (0..3).map(|i| (x[0] - x[i + 1]) * barycentric[i]).sum();
    let distance = delta.length();
    anyhow::ensure!(distance.is_finite() && distance > 1e-12, ContactUnresolved);
    Ok(Witness {
        barycentric,
        normal: delta / distance,
        distance,
    })
}

/// Conservative advancement for a linearly moving point and triangle. The
/// maximum relative vertex speed bounds change of closest-point distance.
fn sweep(old: [DVec3; 4], end: [DVec3; 4], radius: f64) -> anyhow::Result<Option<Witness>> {
    let motion = std::array::from_fn::<_, 4, _>(|i| end[i] - old[i]);
    let speed = (1..4)
        .map(|i| (motion[0] - motion[i]).length())
        .fold(0.0_f64, f64::max);
    let mut time = 0.0;
    for _ in 0..256 {
        let at = std::array::from_fn(|i| old[i] + time * motion[i]);
        let hit = witness(at)?;
        if hit.distance <= radius + 1e-8 {
            return Ok(Some(hit));
        }
        // A separating plane is a lower bound over the entire interval.
        if [at, end]
            .into_iter()
            .all(|p| (1..4).all(|i| (p[0] - p[i]).dot(hit.normal) > radius + 1e-8))
        {
            return Ok(None);
        }
        if speed < 1e-12 || hit.distance - radius > speed * (1.0 - time) {
            return Ok(None);
        }
        time += 0.9 * (hit.distance - radius) / speed;
        if time > 1.0 {
            return Ok(None);
        }
    }
    Err(ContactUnresolved.into())
}

#[cfg(test)]
#[path = "tissue_collision_tests.rs"]
mod tests;
